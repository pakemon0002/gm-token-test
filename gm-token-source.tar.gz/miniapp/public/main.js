// GM TOKEN UI · original layouts + original 216 PNG pack. No third-party icon replacements.
const store = { getItem: (key) => { try {
        return window.localStorage.getItem(key);
    }
    catch {
        return null;
    } }, setItem: (key, value) => { try {
        window.localStorage.setItem(key, value);
    }
    catch { } } };
const A = './assets/icons/';
const BRAND = './assets/brand-original-reference/';
const firstWallet = { gm: 12487, cr: 5000, vault: 25000, xp: 2450, level: 5, claims: 0, lastClaim: '', lastMiningXpDay: '', lastVaultWithdrawDay: '', streak: 7, storage: 8, storageUpdated: Date.now(), tickets: [], orders: [], traded: 0, rewardClaimed: false };
const xpThreshold = [0, 100, 250, 450, 750, 1150, 1700, 2400, 3300, 4400];
const miningBase = [10, 14, 19, 25, 32, 40, 50, 62, 75, 90];
const powerBonus = (lvl) => lvl >= 10 ? 25 : lvl >= 8 ? 20 : lvl >= 6 ? 15 : lvl >= 4 ? 10 : lvl >= 2 ? 5 : 0;
const storageHours = (lvl) => lvl >= 9 ? 24 : lvl >= 7 ? 20 : lvl >= 5 ? 16 : lvl >= 3 ? 12 : 8;
const holdingBonus = (n) => { let p = 0; for (const [limit, b] of [[50, 5], [100, 10], [250, 15], [500, 20], [1000, 25], [2000, 30], [5000, 35], [10000, 40], [25000, 45], [50000, 50]])
    if (n >= limit)
        p = b; return p; };
const gmRate = (v) => miningBase[Math.min(9, Math.max(0, v.level - 1))] * (1 + powerBonus(v.level) / 100) * (1 + holdingBonus(v.vault) / 100);
const nf = (n, dec = 2) => Number(n).toLocaleString('ru-RU', { minimumFractionDigits: dec, maximumFractionDigits: dec });
const clean = (s) => String(s).replace(/[<>]/g, '');
const demoTasks = [{ key: 'telegram', icon: 'telegram', title: 'Присоединиться к Telegram', reward: '+1 000 GM', category: 'Social', desc: 'Демо-задание: проверка подписки требует подключения бота' }, { key: 'x', icon: 'x-social', title: 'Подписаться на новости', reward: '+500 GM', category: 'Social', desc: 'Демо-задание: внешняя проверка не подключена' }, { key: 'vault', icon: 'coins', title: 'Изучить Holding Vault', reward: 'XP за достижение', category: 'Other', desc: 'Открой Vault и ознакомься с условиями' }, { key: 'friends', icon: 'friends', title: 'Пригласить 3 друзей', reward: 'XP за достижение', category: 'Social', desc: 'Засчитываются только реальные подтверждённые регистрации' }];
const darkRanks = [['2', 'Web3Rizz', '980K'], ['1', 'CryptoKing', '1.2M'], ['3', 'TokenMax', '870K']];
const lightRanks = [['2', 'Web3Rizz', '721.4K'], ['1', 'CryptoKing', '942.7K'], ['3', 'TokenMax', '689.7K']];
const chartPrices = [11.55, 11.82, 11.7, 11.9, 12.02, 11.85, 11.79, 12.16, 12.21, 12.12, 12.01, 12.11, 12.48, 12.36, 12.49, 12.77, 12.60, 12.81, 12.66, 12.87, 13.04, 12.85, 13.12, 13.26];
const timeNow = () => new Date().toISOString().slice(0, 10);
const todayUTC = () => new Date().toISOString().slice(0, 10);
function Icon({ name, theme, size = 24, tile = false, alt = '', className = '' }) {
    return React.createElement("img", { className: 'gm-icon ' + className, src: `${A}${theme}/${tile ? 'tiles' : 'transparent'}/${name}.png`, width: size, height: size, alt: alt, draggable: "false", loading: "lazy" });
}
function Brand({ theme, size = 50 }) { return React.createElement("img", { className: "brand-coin", src: BRAND + (theme === 'light' ? 'gm-coin-light-original.png' : 'gm-coin-dark-original.png'), width: size, height: size, alt: "\u041B\u043E\u0433\u043E\u0442\u0438\u043F GM TOKEN", draggable: "false" }); }
function GButton({ children, onClick, light = false, disabled = false, icon, theme }) { return React.createElement("button", { type: "button", className: 'capsule ' + (light ? 'pale' : 'dark-cap'), onClick: onClick, disabled: disabled },
    icon && React.createElement(Icon, { name: icon, theme: theme, size: 22 }),
    React.createElement("span", null, children)); }
function SparkLine({ theme, compact = false }) {
    const pts = [9, 12, 11, 16, 18, 16, 20, 15, 12, 14, 18, 23, 22, 19, 21, 26, 23, 22, 27, 25, 32, 34];
    const w = compact ? 145 : 354, h = compact ? 60 : 134;
    let p = pts.map((a, i) => `${i * w / (pts.length - 1)},${h - 9 - (a - 9) * (h - 18) / 26}`).join(' ');
    return React.createElement("svg", { className: 'sparkline ' + (compact ? 'small' : ''), viewBox: `0 0 ${w} ${h}`, preserveAspectRatio: "none", role: "img", "aria-label": "\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u0433\u0440\u0430\u0444\u0438\u043A \u0438\u0433\u0440\u043E\u0432\u043E\u0433\u043E \u0431\u0430\u043B\u0430\u043D\u0441\u0430" },
        React.createElement("defs", null,
            React.createElement("linearGradient", { id: `under-${compact ? 's' : 'l'}-${theme}`, x1: "0", y1: "0", x2: "0", y2: "1" },
                React.createElement("stop", { stopColor: theme === 'light' ? '#A2A8C1' : '#BEC4D9', stopOpacity: ".52" }),
                React.createElement("stop", { offset: "1", stopColor: "#C3C6D9", stopOpacity: "0" }))),
        !compact && [.25, .5, .75].map((n, i) => React.createElement("line", { key: i, x1: "0", x2: w, y1: n * h, y2: n * h, className: "gridline" })),
        React.createElement("polygon", { points: `0,${h} ${p} ${w},${h}`, fill: `url(#under-${compact ? 's' : 'l'}-${theme})` }),
        React.createElement("polyline", { points: p, fill: "none", stroke: theme === 'light' ? '#4E556A' : '#DDE1EF', strokeWidth: compact ? 2.2 : 2.8, strokeLinecap: "round", strokeLinejoin: "round" }),
        !compact && React.createElement(React.Fragment, null,
            React.createElement("circle", { cx: w * 17 / (pts.length - 1), cy: h - 9 - (pts[17] - 9) * (h - 18) / 26, r: "5.5", fill: theme === 'light' ? '#FFF' : '#111', stroke: theme === 'light' ? '#646C84' : '#CBD1E0', strokeWidth: "2" }),
            React.createElement("text", { className: "chart-callout", x: w * 17 / (pts.length - 1) - 15, y: h - 34 - (pts[17] - 9) * (h - 18) / 26 }, "+8.5%")));
}
function Candles({ theme }) {
    const width = 340, height = 225, min = 11.2, max = 13.6;
    return React.createElement("svg", { className: "candles", role: "img", "aria-label": "\u0414\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0441\u0432\u0435\u0447\u0438 GM/CR", viewBox: "0 0 364 260", preserveAspectRatio: "none" },
        [0, 1, 2, 3, 4].map(i => React.createElement("g", { key: i },
            React.createElement("line", { x1: "0", x2: "330", y1: 25 + i * 45, y2: 25 + i * 45, className: "chart-grid" }),
            React.createElement("text", { x: "342", y: 28 + i * 45, className: "price-label" }, nf(13.5 - i * .55, 2)))),
        [1, 2, 3, 4, 5, 6].map(i => React.createElement("line", { key: i, y1: "12", y2: "225", x1: i * 49, x2: i * 49, className: "chart-grid" })),
        chartPrices.map((v, i) => { let prev = i ? chartPrices[i - 1] : 11.4; let open = prev + (i % 3 - 1) * .10; let close = v; let high = Math.max(open, close) + (.10 + (i % 4) * .035), low = Math.min(open, close) - (.08 + (i % 3) * .04); let y = (n) => 24 + (max - n) / (max - min) * 178; let positive = close >= open; let x = 10 + i * 13.1; const col = theme === 'dark' ? (positive ? '#5ABBA4' : '#D7809B') : (positive ? '#383B4B' : '#8F97AB'); return React.createElement("g", { key: i },
            React.createElement("line", { x1: x + 4, y1: y(high), x2: x + 4, y2: y(low), stroke: col, strokeWidth: "1.3" }),
            React.createElement("rect", { x: x, y: Math.min(y(open), y(close)), width: "8.2", height: Math.max(3, Math.abs(y(open) - y(close))), fill: col, rx: ".9" }),
            React.createElement("rect", { x: x, y: 228 - (i * 3 + 13) % 31, width: "8.2", height: 16 + (i * 3 + 13) % 31, fill: theme === 'dark' ? '#57535E' : '#BAC0D0', opacity: ".65" })); }));
}
function BarButton({ name, title, theme, selected = false, onClick }) { return React.createElement("button", { className: 'nav-entry ' + (selected ? 'active' : ''), onClick: onClick, "aria-label": title, "aria-current": selected ? 'page' : undefined },
    React.createElement(Icon, { theme: theme, name: name, size: 23 }),
    React.createElement("span", null, title)); }
function App() {
    const webapp = window.Telegram?.WebApp;
    const [theme, setTheme] = React.useState((store.getItem('gm_theme') || webapp?.colorScheme || 'light') === 'dark' ? 'dark' : 'light');
    const [screen, setScreen] = React.useState('home');
    const [wallet, setWallet] = React.useState(() => { try {
        return { ...firstWallet, ...JSON.parse(store.getItem('gm_demo_wallet') || '{}') };
    }
    catch {
        return firstWallet;
    } });
    const [toast, setToast] = React.useState('');
    const [period, setPeriod] = React.useState('1D');
    const [side, setSide] = React.useState('buy');
    const [amount, setAmount] = React.useState('100');
    const [taskFilter, setTaskFilter] = React.useState('All');
    const [rankFilter, setRankFilter] = React.useState('Global');
    const [shopAmount, setShopAmount] = React.useState('100');
    const [vaultAmount, setVaultAmount] = React.useState('1000');
    const [supportText, setSupportText] = React.useState('');
    const [supportTickets, setSupportTickets] = React.useState([]);
    const [staffReply, setStaffReply] = React.useState('');
    const [supportCategory, setSupportCategory] = React.useState('Общий вопрос');
    const [liveState, setLiveState] = React.useState(null);
    const [liveOrders, setLiveOrders] = React.useState([]);
    const [liveBook, setLiveBook] = React.useState(null);
    const [liveTasks, setLiveTasks] = React.useState([]);
    const [liveAchievements, setLiveAchievements] = React.useState([]);
    const [liveReferrals, setLiveReferrals] = React.useState(null);
    const [liveRanks, setLiveRanks] = React.useState(null);
    const [shopQuote, setShopQuote] = React.useState(null);
    const [orderType, setOrderType] = React.useState('limit');
    const [orderPrice, setOrderPrice] = React.useState('12.40');
    const [orderDuration, setOrderDuration] = React.useState('24h');
    const [tradeReady, setTradeReady] = React.useState(false);
    const [serverHistory, setServerHistory] = React.useState([]);
    const [demo, setDemo] = React.useState(true);
    const [liveRole, setLiveRole] = React.useState('player');
    const [adminId, setAdminId] = React.useState('');
    const [adminCode, setAdminCode] = React.useState('');
    const [adminAction, setAdminAction] = React.useState('grant');
    const [adminTeam, setAdminTeam] = React.useState([]);
    const [adminFunds, setAdminFunds] = React.useState([]);
    const [adminAmount, setAdminAmount] = React.useState('1000');
    const [adminFrom, setAdminFrom] = React.useState('TREASURY');
    const [adminTo, setAdminTo] = React.useState('MINING');
    const [adminReason, setAdminReason] = React.useState('Пополнение игрового фонда по решению владельца');
    const [adminCorrectionCurrency, setAdminCorrectionCurrency] = React.useState('GM');
    const [adminCorrectionPool, setAdminCorrectionPool] = React.useState('MINING');
    const [adminTicket, setAdminTicket] = React.useState('');
    const [backendStatus, setBackendStatus] = React.useState('Демо / сервер не подключён');
    const [modal, setModal] = React.useState('');
    const [modalText, setModalText] = React.useState('');
    const toastRef = React.useRef(0);
    const flash = (msg) => { setToast(msg); toastRef.current++; };
    const setW = (patch) => setWallet((w) => ({ ...w, ...(typeof patch === 'function' ? patch(w) : patch) }));
    const goto = (s) => { setScreen(s); try {
        history.pushState(null, '', '#' + s);
    }
    catch { } ; document.querySelector('.phone-scroll')?.scrollTo(0, 0); };
    React.useEffect(() => { try {
        store.setItem('gm_theme', theme);
    }
    catch { } ; webapp?.setBackgroundColor?.(theme === 'dark' ? '#030406' : '#E8EAF4'); }, [theme]);
    React.useEffect(() => { try {
        store.setItem('gm_demo_wallet', JSON.stringify(wallet));
    }
    catch { } }, [wallet]);
    React.useEffect(() => { webapp?.ready?.(); webapp?.expand?.(); const init = webapp?.initData; if (!init)
        return; fetch('/api/bootstrap', { headers: { 'Authorization': `tma ${init}` } }).then(async (r) => { if (!r.ok)
        throw Error('auth'); const d = await r.json(); setDemo(false); setLiveRole(d.user?.role || 'player'); setBackendStatus(`Telegram аккаунт: ${d.user?.id || 'подтверждён'}`); if (d.wallet)
        setW((w) => ({ ...w, gm: d.wallet.gm / 100, cr: d.wallet.cr / 100, vault: d.wallet.vault / 100, level: d.user.level, xp: d.user.xp })); }).catch(() => { setDemo(true); setBackendStatus('Демо — сервер недоступен'); }); }, []);
    const api = async (path, payload) => {
        const init = webapp?.initData;
        if (!init) {
            flash('Открой приложение внутри Telegram через @gm_token_test_bot');
            return null;
        }
        try {
            const r = await fetch(path, { method: payload ? 'POST' : 'GET', headers: { Authorization: 'tma ' + init, 'Content-Type': 'application/json' }, body: payload ? JSON.stringify(payload) : undefined });
            const d = await r.json();
            if (!r.ok)
                throw Error(d.error || 'Ошибка сервера');
            return d;
        }
        catch (e) {
            flash('Ошибка: ' + (e.message || e));
            return null;
        }
    };
    const refreshLive = async () => { if (!webapp?.initData)
        return; const d = await api('/api/game/status'); if (!d)
        return; setLiveState(d); setW((w) => ({ ...w, gm: d.wallet.gm / 100, cr: d.wallet.cr / 100, vault: d.wallet.vault / 100, storage: d.mining.pending_cents / 100, level: d.user?.level || w.level, xp: d.user?.xp ?? w.xp })); const [orders, book, tasks, achievements, refs, ranks] = await Promise.all([api('/api/exchange/orders'), api('/api/exchange/book'), api('/api/tasks'), api('/api/achievements'), api('/api/referrals/me'), api('/api/leaderboard')]); if (orders)
        setLiveOrders(orders.orders || []); if (book)
        setLiveBook(book); if (tasks)
        setLiveTasks(tasks.tasks || []); if (achievements)
        setLiveAchievements(achievements.achievements || []); if (refs)
        setLiveReferrals(refs); if (ranks)
        setLiveRanks(ranks); };
    const gameAction = async (path, payload = {}) => { const result = await api(path, { operationId: cryptoId(), ...payload }); if (result) {
        if (result.wallet)
            setW((w) => ({ ...w, gm: result.wallet.gm / 100, cr: result.wallet.cr / 100, vault: result.wallet.vault / 100 }));
        await refreshLive();
        flash('Операция подтверждена сервером');
    } return result; };
    React.useEffect(() => { if (demo)
        return; refreshLive(); const timer = setInterval(() => { refreshLive(); }, 30000); return () => clearInterval(timer); }, [demo]);
    const nav = (s) => goto(s);
    const adminRequest = async (path, payload) => {
        if (demo || !webapp?.initData) {
            flash('Только после Telegram-авторизации владельца');
            return;
        }
        try {
            const response = await fetch(path, { method: payload ? 'POST' : 'GET', headers: { Authorization: 'tma ' + webapp.initData, 'Content-Type': 'application/json' }, body: payload ? JSON.stringify(payload) : undefined });
            const x = await response.json();
            if (!response.ok)
                throw Error(x.error || 'Сервер отказал');
            flash('Операция выполнена');
            return x;
        }
        catch (e) {
            flash('Ошибка: ' + String(e.message || e));
            return null;
        }
    };
    const adminChangeRole = () => adminRequest('/api/admin/moderators', { telegramId: adminId, code: adminCode, action: adminAction }).then(() => adminRequest('/api/admin/team').then(x => x && setAdminTeam(x.team || [])));
    const adminTransfer = () => adminRequest('/api/admin/transfer', { source: adminFrom, target: adminTo, amount: adminAmount, code: adminCode, reason: adminReason, operationId: cryptoId() }).then(() => adminRequest('/api/admin/pools').then(x => x && setAdminFunds(x.pools || [])));
    const adminCorrection = () => adminRequest('/api/admin/correction', { userId: adminId, sourcePool: adminCorrectionPool, currency: adminCorrectionCurrency, amount: adminAmount, direction: 'credit', ticket: adminTicket, code: adminCode, reason: adminReason, operationId: cryptoId() });
    function cryptoId() { return (window.crypto && window.crypto.randomUUID) ? window.crypto.randomUUID() : 'manual-' + Date.now() + '-' + Math.floor(Math.random() * 999999); }
    const todayClaim = async () => { if (!demo) {
        const x = await gameAction('/api/daily/claim');
        if (x)
            goto('reward');
        return;
    } if (wallet.lastClaim === todayUTC()) {
        flash('Сегодня награда уже получена');
        return;
    } setW((w) => ({ ...w, gm: Math.round((w.gm + 10) * 100) / 100, lastClaim: todayUTC(), streak: w.streak + 1, rewardClaimed: true })); goto('reward'); flash('Демо-награда: +10 GM (локальная)'); };
    const miningClaim = async () => { if (!demo) {
        await gameAction('/api/mining/claim');
        return;
    } if (wallet.storage < 1) {
        flash('Для Claim накопи минимум 1 GM');
        return;
    } const earned = Math.floor(wallet.storage * 100) / 100; setW((w) => ({ ...w, gm: Math.round((w.gm + earned) * 100) / 100, storage: 0, storageUpdated: Date.now(), xp: w.xp + (w.lastMiningXpDay === todayUTC() ? 0 : 20), lastMiningXpDay: todayUTC() })); flash('Демо Claim ' + nf(earned) + ' GM'); };
    const depositVault = async () => { if (!demo) {
        await gameAction('/api/vault/deposit', { amount: vaultAmount.replace(',', '.') });
        return;
    } const n = Number(vaultAmount.replace(',', '.')); if (!(n > 0 && n <= wallet.gm)) {
        flash('Проверь доступный баланс');
        return;
    } setW((w) => ({ ...w, gm: Math.round((w.gm - n) * 100) / 100, vault: Math.round((w.vault + n) * 100) / 100 })); flash('Демо-депозит'); };
    const withdrawVault = async () => { if (!demo) {
        await gameAction('/api/vault/withdraw', { amount: vaultAmount.replace(',', '.') });
        return;
    } const n = Number(vaultAmount.replace(',', '.')); if (!(n > 0 && n <= wallet.vault && (n >= 1000 || n === wallet.vault))) {
        flash('Частичный вывод от 1 000 GM, полный — любой остаток');
        return;
    } if (wallet.lastVaultWithdrawDay === todayUTC()) {
        flash('Разрешён один вывод в сутки');
        return;
    } setW((w) => ({ ...w, gm: Math.round((w.gm + n * .95) * 100) / 100, vault: Math.round((w.vault - n) * 100) / 100, lastVaultWithdrawDay: todayUTC() })); flash('Демо-вывод'); };
    const submitOrder = async () => { if (demo) {
        flash('Демо: ордера не отправляются');
        setModal('');
        return;
    } const request = { type: orderType, side, amount: amount.replace(',', '.'), price: orderPrice.replace(',', '.'), duration: orderDuration }; const x = await gameAction('/api/exchange/order', request); if (x) {
        setModal('');
        setTradeReady(false);
        flash(x.auction ? 'Заявка принята на стартовый аукцион' : `Ордер создан. Исполнено: ${nf((x.filled_gm_cents || 0) / 100)} GM`);
    } };
    const cancelLiveOrder = async (id) => { await gameAction('/api/exchange/cancel', { orderId: id }); };
    const loadHistory = async () => { if (demo)
        return; const x = await api('/api/history'); if (x)
        setServerHistory(x.events || []); };
    const tradePreview = () => { const n = Number(amount.replace(',', '.')); if (!(n >= 10)) {
        flash('Минимум нового ордера — 10 GM');
        return;
    } setModalText(`${side === 'buy' ? 'Покупка' : 'Продажа'} ${nf(n)} GM, ${orderType === 'limit' ? 'лимит ' + orderPrice + ' CR/GM' : 'рыночная цена ±3%'}. Комиссия: 0,5% с обеих сторон. ${demo ? 'ДЕМО, заявка не отправляется.' : 'Подтверди заявку для отправки на сервер.'}`); setTradeReady(true); setModal('order'); };
    const loadTickets = async () => {
        if (demo) {
            flash('В демо используются локальные обращения');
            return;
        }
        try {
            const r = await fetch('/api/tickets', { headers: { Authorization: 'tma ' + webapp?.initData } });
            const x = await r.json();
            if (!r.ok)
                throw Error(x.error);
            setSupportTickets(x.tickets || []);
        }
        catch (e) {
            flash('Ошибка получения тикетов: ' + e.message);
        }
    };
    const ticketAction = async (id, action, payload = {}) => {
        const x = await adminRequest(`/api/tickets/${id}/${action}`, payload);
        if (x)
            loadTickets();
    };
    const createTicket = async () => {
        if (supportText.trim().length < 10) {
            flash('Опиши проблему минимум в 10 символах');
            return;
        }
        if (!demo) {
            const x = await adminRequest('/api/tickets', { category: supportCategory, body: supportText });
            if (x) {
                setSupportText('');
                await loadTickets();
            }
            return;
        }
        const ticket = { id: '#DEMO-' + Math.floor(Date.now() / 1000), category: supportCategory, body: supportText, status: 'Новый' };
        setW((w) => ({ ...w, tickets: [ticket, ...w.tickets] }));
        setSupportText('');
        flash('Демо-тикет создан только на этом устройстве');
    };
    const icon = (n, size = 23, tile = false) => React.createElement(Icon, { name: n, theme: theme, size: size, tile: tile });
    const isLight = theme === 'light';
    const top = (title, back = true, right = 'more') => React.createElement("header", { className: 'screen-header ' + (!isLight ? 'dark-head' : '') },
        React.createElement("button", { className: "header-icon", "aria-label": "\u041D\u0430\u0437\u0430\u0434", onClick: () => back ? goto('home') : flash('Меню') }, back ? icon('chevron-left', 24) : React.createElement(Brand, { theme: theme, size: 35 })),
        React.createElement("strong", null, title),
        React.createElement("button", { className: "header-icon", onClick: () => right === 'settings' ? goto('settings') : goto('more'), "aria-label": "\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F" }, icon(right, 23)));
    const menuItems = [['home', 'home', 'Home'], ['trade', 'candlesticks', 'Trade'], ['earn', isLight ? 'gift' : 'settings', isLight ? 'Tasks' : 'Earn'], ['profile', 'profile', 'Profile']];
    const bottom = () => React.createElement("nav", { className: "bottom-nav", "aria-label": "\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0440\u0430\u0437\u0434\u0435\u043B\u044B" }, menuItems.map(([s, i, t]) => React.createElement(BarButton, { key: s, name: i, theme: theme, title: t, selected: screen === s || (isLight && s === 'earn' && screen === 'tasks') || (!isLight && s === 'earn' && screen === 'tasks'), onClick: () => goto(s === 'earn' && isLight ? 'tasks' : s) })));
    function Home() { return isLight ? React.createElement(React.Fragment, null,
        React.createElement("header", { className: "home-header" },
            React.createElement("span", { className: "hbrand" },
                React.createElement(Brand, { theme: theme, size: 38 }),
                React.createElement("b", null, "GM TOKEN")),
            React.createElement("button", { className: "header-icon", onClick: () => goto('settings'), "aria-label": "\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F" }, icon('notifications', 24))),
        React.createElement("div", { className: "balance-glass pearl-card" },
            React.createElement("div", { className: "balance-top" },
                React.createElement("div", null,
                    React.createElement("small", null, "Your Balance"),
                    React.createElement("div", { className: "balance-numeral" },
                        nf(wallet.gm, 0),
                        React.createElement("span", null, " GM")),
                    React.createElement("span", { className: "green" },
                        "\u25B2 +8.5% ",
                        React.createElement("small", null, "\u0414\u0415\u041C\u041E"))),
                React.createElement("div", { className: "balance-graph-icon" }, icon('bar-chart', 41))),
            React.createElement(SparkLine, { theme: theme })),
        React.createElement("button", { className: "collect-claim", onClick: () => goto('reward') },
            React.createElement("div", { className: "claim-electric" }, icon('lightning', 32)),
            React.createElement("span", null,
                React.createElement("strong", null, "Claim Reward"),
                React.createElement("small", null, "Get your daily GM")),
            icon('chevron-right', 24)),
        React.createElement("button", { className: "streak-card pearl-card", onClick: () => goto('streak') },
            icon('flame', 48),
            React.createElement("span", null,
                React.createElement("b", null, "7 Day Streak"),
                React.createElement("span", { className: "streak-dots" },
                    "\u25CF \u25CF \u25CF \u25CF \u25CF ",
                    React.createElement("i", null, "\u25CF \u25CF"))),
            icon('chevron-right', 22)),
        React.createElement("div", { className: "quick-grid" }, [['candlesticks', 'Trade', 'trade'], ['gift', 'Earn', 'earn'], ['friends', 'Invite', 'referrals'], ['more', 'More', 'more']].map(([i, t, s]) => React.createElement("button", { className: "quick-card pearl-card", key: t, onClick: () => goto(s) },
            icon(i, 27),
            React.createElement("span", null, t))))) : React.createElement(React.Fragment, null,
        React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('settings') },
                icon('more', 21),
                " ",
                icon('close', 18))),
        React.createElement("div", { className: "orbit-hero" },
            React.createElement(Brand, { theme: "dark", size: 93 }),
            React.createElement("span", { className: "planet-ring" })),
        React.createElement("div", { className: "dark-balance" },
            React.createElement("div", null,
                nf(wallet.gm, 0),
                React.createElement("span", { className: "currency-mark" }, " GM")),
            React.createElement("p", { className: "green" },
                "+512 \u00A0 +4.3% \u2191 ",
                React.createElement("small", null, "\u0414\u0415\u041C\u041E"))),
        React.createElement("div", { className: "dark-spark" },
            React.createElement(SparkLine, { theme: "dark" }),
            React.createElement("button", { onClick: () => setPeriod(period === '24h' ? '7d' : '24h') },
                period === '1D' ? '24h' : period,
                " ",
                icon('chevron-down', 13))),
        React.createElement("button", { className: "dark-reward metallic-card", onClick: () => goto('reward') },
            icon('lightning', 30),
            React.createElement("span", null,
                React.createElement("b", null, "Collect Reward"),
                React.createElement("small", null, wallet.lastClaim === todayUTC() ? 'Claimed today' : 'Get daily GM'))),
        React.createElement("button", { className: "dark-streak metallic-card", onClick: () => goto('streak') },
            icon('flame', 48),
            React.createElement("span", null,
                React.createElement("b", null, "Daily Streak"),
                React.createElement("strong", null,
                    wallet.streak,
                    " days")),
            icon('chevron-right', 18))); }
    function Trading() { return isLight ? React.createElement(React.Fragment, null,
        top('Trading', true, 'bar-chart'),
        React.createElement("div", { className: "trade-meta" },
            React.createElement("div", null,
                "GM/CR ",
                icon('chevron-down', 13)),
            React.createElement("button", { className: "naked", onClick: () => flash('Избранное — демо') }, icon('star', 22))),
        React.createElement("div", { className: "price-big" }, demo ? "12.40" : liveBook?.last_price ? nf(liveBook.last_price / 100) : "—"),
        React.createElement("div", { className: "green trade-green" }, demo ? "▲ +6.7% · ДЕМО" : "CR/GM · " + (liveBook?.last_price ? "последняя сделка" : "цены пока нет")),
        React.createElement("div", { className: "intervals" }, ['1D', '1W', '1M', '3M', '1Y'].map(s => React.createElement("button", { className: period === s ? 'on' : '', key: s, onClick: () => setPeriod(s) }, s))),
        React.createElement(Candles, { theme: theme }),
        React.createElement("p", { className: "disclaimer" },
            "\u0413\u0440\u0430\u0444\u0438\u043A \u2014 \u043F\u0440\u0438\u043C\u0435\u0440 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u044F, \u043D\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0442\u043E\u0440\u0433\u043E\u0432. \u0426\u0435\u043D\u0430 \u0432\u044B\u0448\u0435 ",
            demo ? "демонстрационная" : "получена из серверной истории",
            "."),
        React.createElement("div", { className: "pair-trade-buttons" },
            React.createElement("button", { onClick: () => { setSide('buy'); setModal('tradeForm'); } }, "Buy"),
            React.createElement("button", { onClick: () => { setSide('sell'); setModal('tradeForm'); } }, "Sell")),
        React.createElement("div", { className: "order-header" },
            React.createElement("b", null, "Your Orders"),
            React.createElement("button", { onClick: () => goto('history') },
                "View All ",
                icon('chevron-right', 15))),
        React.createElement("button", { className: "order-snippet pearl-card", onClick: () => goto('history'), style: demo ? {} : { display: "none" } },
            React.createElement(Brand, { theme: theme, size: 37 }),
            React.createElement("div", null,
                React.createElement("b", null, "Buy 1,000 GM"),
                React.createElement("span", null, "\u2248 12 400 CR \u00B7 \u043E\u0431\u0440\u0430\u0437\u0435\u0446")),
            React.createElement("span", { className: "green" },
                icon('check', 15),
                " Demo")),
        !demo && React.createElement("div", { className: "form-surface pearl-card" },
            React.createElement("b", null, "\u041C\u043E\u0438 \u043E\u0440\u0434\u0435\u0440\u0430"),
            liveOrders.filter((x) => x.status === 'open').slice(0, 8).map((x) => React.createElement("div", { key: x.id, className: "split-line" },
                React.createElement("span", null,
                    x.side,
                    " \u00B7 ",
                    nf(x.remaining_cents / 100),
                    " GM \u00B7 ",
                    nf(x.limit_price / 100),
                    " CR"),
                React.createElement("button", { onClick: () => cancelLiveOrder(x.id) }, "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C"))),
            React.createElement("button", { onClick: refreshLive }, "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u0442\u0430\u043A\u0430\u043D"),
            React.createElement("small", null, liveBook?.auction_done ? 'Торги активны' : 'Стартовый аукцион'))) : React.createElement(React.Fragment, null,
        React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('settings') },
                icon('more', 22),
                " ",
                icon('close', 18))),
        React.createElement("div", { className: "dark-trade-price" },
            React.createElement("div", null,
                demo ? "12.40" : liveBook?.last_price ? nf(liveBook.last_price / 100) : "—",
                " ",
                React.createElement("small", null, "CR")),
            React.createElement("span", { className: "green" }, demo ? "▲ +6.7% · ДЕМО" : liveBook?.last_price ? "последняя цена GM/CR" : "пока нет сделок")),
        React.createElement(Candles, { theme: "dark" }),
        React.createElement("p", { className: "disclaimer" }, "\u0421\u0432\u0435\u0447\u0438 \u2014 \u0434\u0435\u043C\u043E\u043D\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u043E\u0431\u0440\u0430\u0437\u0435\u0446, \u043D\u0435 \u0440\u044B\u043D\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435."),
        React.createElement("div", { className: "dark-candle-switch" },
            React.createElement("span", null, period),
            React.createElement("button", { onClick: () => setPeriod(period === '1D' ? '1W' : '1D') },
                "24h ",
                icon('chevron-down', 14))),
        React.createElement("div", { className: "dark-intervals" }, ['1D', '1W', '1M', '3M'].map(x => React.createElement("button", { key: x, onClick: () => setPeriod(x), className: period === x ? 'on' : '' }, x))),
        React.createElement("div", { className: "dark-trade-side" },
            React.createElement("button", { className: side === 'buy' ? 'chosen' : '', onClick: () => setSide('buy') }, "Buy"),
            React.createElement("button", { className: side === 'sell' ? 'chosen' : '', onClick: () => setSide('sell') }, "Sell")),
        React.createElement("div", { className: "amount-entry" },
            React.createElement("input", { "aria-label": "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E GM", inputMode: "decimal", value: amount, onChange: (e) => setAmount(e.target.value) }),
            React.createElement("b", null, "GM")),
        React.createElement("div", { className: "amount-presets" }, ['25%', '50%', '75%', 'Max'].map((x, i) => React.createElement("button", { key: x, onClick: () => setAmount(String([25, 50, 75, 100][i])) }, x))),
        React.createElement("button", { className: "silver-action", onClick: () => setModal('tradeForm') }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u043E\u0440\u0434\u0435\u0440")); }
    function Earn() { return React.createElement(React.Fragment, null,
        !isLight ? React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('settings') },
                icon('more', 22),
                " ",
                icon('close', 17))) : top('Earn', true, 'gift'),
        React.createElement("div", { className: 'earn-total ' + (isLight ? 'pearl-card' : 'metallic-card') },
            React.createElement("div", null,
                React.createElement("small", null, "Total Earned"),
                React.createElement("div", { className: "earned-number" },
                    demo ? "2 840" : nf(wallet.gm, 0),
                    " ",
                    React.createElement("span", null, "GM"))),
            icon('trending-up', 48)),
        React.createElement("h3", { className: "section-title" }, "Earn Methods"),
        React.createElement("div", { className: "earn-methods" }, [['gift', 'Daily Reward', 'Get free GM tokens every day', 'reward'], ['coins', 'Hold & Earn', 'Earn game rewards for holding', 'vault'], ['tasks', 'Tasks', 'Complete tasks and earn more', 'tasks'], ['friends', 'Invite Friends', 'Get bonuses for referrals', 'referrals'], ['lightning', 'Mining', 'Play to earn virtual GM', 'mining'], ['swap', 'GM Shop', 'Exchange virtual GM into CR', 'shop']].map(([i, title, description, s]) => React.createElement("button", { key: title, className: 'earn-item ' + (isLight ? 'pearl-card' : 'metallic-card'), onClick: () => goto(s) },
            icon(i, 48, true),
            React.createElement("span", null,
                React.createElement("b", null, title),
                React.createElement("small", null, description)),
            icon('chevron-right', 19))))); }
    function Tasks() { return React.createElement(React.Fragment, null,
        isLight ? top('Tasks', true, 'tasks') : React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('settings') },
                icon('more', 23),
                " ",
                icon('close', 17))),
        !isLight && React.createElement("button", { className: "task-promo metallic-card", onClick: () => flash('Бонусы доступны только после проверки условий') },
            icon('tasks', 55),
            React.createElement("b", null,
                "Complete tasks",
                React.createElement("br", null),
                "and earn GM")),
        React.createElement("div", { className: "task-tabs" }, ['All', 'Social', 'Crypto', 'Other'].map(x => React.createElement("button", { className: taskFilter === x ? 'on' : '', key: x, onClick: () => setTaskFilter(x) }, x))),
        isLight && React.createElement("button", { className: "task-promo pearl-card", onClick: () => flash('Демо: задания будут доступны после запуска') },
            icon('gift', 54),
            React.createElement("b", null,
                "Complete tasks",
                React.createElement("br", null),
                "and earn GM"),
            icon('chevron-right', 20)),
        React.createElement("div", { className: "tasks-list" }, (demo ? demoTasks : liveTasks.map((t) => ({ key: t.id, icon: t.icon || 'tasks', title: t.title || t.id, reward: `${t.gm || 0} GM · ${t.xp || 0} XP`, category: t.category || 'Other', desc: t.description || '', available: t.available, claimed: t.claimed }))).filter((t) => taskFilter === 'All' || taskFilter === t.category).map(t => React.createElement("div", { className: 'task-row ' + (isLight ? 'pearl-card' : 'metallic-card'), key: t.key },
            icon(t.icon, 40, true),
            React.createElement("span", null,
                React.createElement("b", null, t.title),
                React.createElement("small", { className: "green" }, t.reward)),
            React.createElement("button", { disabled: !demo && (t.claimed || !t.available), onClick: async () => { if (demo) {
                    if (t.key === 'vault')
                        goto('vault');
                    else
                        flash(t.desc);
                    return;
                } const x = await gameAction('/api/tasks/claim', { id: t.key }); if (x)
                    await refreshLive(); } }, demo ? 'Start' : t.claimed ? 'Получено' : t.available ? 'Получить' : 'Не выполнено')))),
        isLight && React.createElement("button", { className: "premium-box pearl-card", onClick: () => flash('Premium Tasks: функция не утверждена для запуска') },
            icon('diamond', 40),
            React.createElement("span", null,
                React.createElement("b", null, "Premium Tasks"),
                React.createElement("small", null, "\u041D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u0432 \u0434\u0435\u043C\u043E")),
            icon('chevron-right', 21))); }
    function Leaderboard() { const ranks = isLight ? lightRanks : darkRanks; if (!demo)
        return React.createElement(React.Fragment, null,
            top('Leaderboard', true, 'bar-chart'),
            React.createElement("div", { className: "rank-tabs" },
                React.createElement("button", { onClick: () => setRankFilter('Global'), className: rankFilter === 'Global' ? 'on' : '' }, "Global"),
                React.createElement("button", { onClick: () => setRankFilter('Friends'), className: rankFilter === 'Friends' ? 'on' : '' }, "Friends")),
            React.createElement("div", { className: "leader-rows" }, (liveRanks?.users || []).filter((u) => rankFilter === 'Global' || (liveReferrals?.referred || []).some((r) => r.user_id === u.id)).map((u, i) => React.createElement("div", { className: "leader-row", key: u.id },
                React.createElement("b", null, i + 1),
                icon('profile', 27),
                React.createElement("span", null, clean(u.username || 'Игрок')),
                React.createElement("small", null,
                    nf(u.score_cents / 100),
                    " GM")))),
            !liveRanks?.users?.length && React.createElement("p", { className: "disclaimer" }, "\u0420\u0435\u0439\u0442\u0438\u043D\u0433 \u043F\u043E\u043A\u0430 \u043F\u0443\u0441\u0442.")); return React.createElement(React.Fragment, null,
        isLight ? top('Leaderboard', true, 'bar-chart') : React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('home') },
                icon('more', 20),
                " ",
                icon('close', 17))),
        React.createElement("div", { className: "rank-tabs" },
            React.createElement("button", { onClick: () => setRankFilter('Global'), className: rankFilter === 'Global' ? 'on' : '' }, isLight ? 'Global' : 'Top Users'),
            React.createElement("button", { onClick: () => setRankFilter('Friends'), className: rankFilter === 'Friends' ? 'on' : '' }, "Friends")),
        React.createElement("div", { className: "podium" }, ranks.map(([place, name, score]) => React.createElement("div", { key: place, className: 'podium-member ' + (place === '1' ? 'winner' : '') },
            place === '1' && icon('crown', 30),
            React.createElement("div", { className: "podium-avatar" }, icon('profile', 34)),
            React.createElement("strong", null, place),
            React.createElement("b", null, name),
            React.createElement("span", null,
                score,
                " GM")))),
        React.createElement("div", { className: "leader-rows" }, [['4', 'Trader007', '740K'], ['5', 'GMLegend', '620K'], ['6', 'You', '12.4K'], ['7', 'NFTDream', '487K'], ['8', 'CryptoPro', '461K']].filter((x) => rankFilter === 'Global' || x[0] === '6').map(([num, name, score]) => React.createElement("div", { className: 'leader-row ' + (name === 'You' ? 'you' : ''), key: num },
            React.createElement("b", null, num),
            icon('profile', 27),
            React.createElement("span", null, name),
            React.createElement("small", null,
                score,
                " GM")))),
        isLight && React.createElement("div", { className: "rank-summary pearl-card" },
            React.createElement(Brand, { theme: "light", size: 43 }),
            React.createElement("div", null,
                React.createElement("small", null, "Your Rank"),
                React.createElement("b", null, "#6")),
            React.createElement(SparkLine, { compact: true, theme: "light" }))); }
    function Profile() { return React.createElement(React.Fragment, null,
        isLight ? React.createElement("header", { className: "profile-top" },
            React.createElement("span", null),
            React.createElement("button", { className: "header-icon", onClick: () => goto('settings') }, icon('settings', 25))) : React.createElement("header", { className: "dark-top" },
            React.createElement("b", null, "GM TOKEN"),
            React.createElement("button", { onClick: () => goto('settings') },
                icon('more', 20),
                " ",
                icon('close', 17))),
        React.createElement("div", { className: "profile-hero" },
            React.createElement(Brand, { theme: theme, size: isLight ? 103 : 98 }),
            React.createElement("h2", null, demo ? "GM_Holder" : (webapp?.initDataUnsafe?.user?.username || webapp?.initDataUnsafe?.user?.first_name || "Игрок")),
            React.createElement("p", null,
                "#",
                demo ? "48271" : String(webapp?.initDataUnsafe?.user?.id || ""),
                " ",
                React.createElement("button", { className: "inline-icon", onClick: () => { navigator.clipboard?.writeText(String(demo ? '48271' : webapp?.initDataUnsafe?.user?.id || '')); flash('ID скопирован'); } }, icon('copy', 15)))),
        React.createElement("div", { className: "xp-area" },
            React.createElement("div", { className: "xp-line" },
                React.createElement("b", null,
                    "Lv. ",
                    wallet.level),
                React.createElement("small", null,
                    nf(wallet.xp, 0),
                    " / ",
                    nf(xpThreshold[Math.min(wallet.level, 9)] || 4400, 0),
                    " XP")),
            React.createElement("div", { className: "progress" },
                React.createElement("div", { style: { width: (Math.min(100, 100 * wallet.xp / (xpThreshold[Math.min(wallet.level, 9)] || 4400))) + '%' } }))),
        React.createElement("div", { className: "stats-grid" }, [['friends', demo ? '128' : String(liveReferrals?.referred?.length || 0), 'Friends'], ['wallet', nf(wallet.gm, 0), 'Balance'], ['lightning', String(wallet.streak), 'Streak']].map(([i, n, label]) => React.createElement("div", { className: "stat-card", key: label },
            icon(i, 23),
            React.createElement("b", null, n),
            React.createElement("small", null, label)))),
        React.createElement("div", { className: "profile-menu" }, [['trophy', 'Achievements', 'achievements'], ['friends', 'Referral Program', 'referrals'], ['clock', 'Transaction History', 'history'], ['settings', 'Settings', 'settings'], ['info', 'Support', 'support']].map(([i, t, s]) => React.createElement("button", { key: t, onClick: () => goto(s) },
            icon(i, 21),
            React.createElement("span", null, t),
            icon('chevron-right', 18)))),
        isLight && React.createElement("button", { className: "logout", onClick: () => flash('Закрой Mini App в Telegram. Демо-профиль не требует выхода') },
            icon('logout', 20),
            " Log Out")); }
    function Reward() { return React.createElement("div", { className: "reward-view" },
        React.createElement("button", { className: "reward-close", onClick: () => goto('home') }, icon('close', 23)),
        React.createElement("div", { className: "reward-shine" },
            React.createElement(Brand, { theme: theme, size: 220 }),
            React.createElement("div", { className: "reward-star" }, icon('star', 32))),
        React.createElement("h1", null, demo ? '+10 GM' : (liveState?.config?.daily_enabled ? 'Daily GM' : 'Daily Reward')),
        React.createElement("p", null, demo ? 'Демо-награда без серверного начисления' : (liveState?.config?.daily_enabled ? 'Получение подтверждается сервером' : 'Размер ежедневной награды ещё не утверждён')),
        React.createElement(GButton, { theme: theme, onClick: () => { if (wallet.lastClaim !== todayUTC())
                todayClaim();
            else
                goto('home'); } }, wallet.lastClaim === todayUTC() ? 'Отлично!' : 'Забрать награду')); }
    function Splash() { return React.createElement("div", { className: "splash-view" },
        React.createElement("div", { className: "splash-glow" }),
        React.createElement("div", { className: "splash-logo" },
            React.createElement("img", { src: BRAND + 'gm-lettermark-metallic-transparent.png', alt: "GM TOKEN" })),
        React.createElement("h1", null, "GM TOKEN"),
        React.createElement("p", null, "Earn \u00B7 Hold \u00B7 Grow"),
        React.createElement("button", { className: "splash-start", onClick: () => goto('home') }, "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435")); }
    function Mining() { const rate = !demo && liveState ? liveState.mining.rate_cents_day / 100 : gmRate(wallet); return React.createElement(React.Fragment, null,
        top('Mining', true, 'info'),
        React.createElement("div", { className: "inferred-label" }, "\u0418\u0433\u0440\u043E\u0432\u043E\u0439 \u0440\u0430\u0437\u0434\u0435\u043B \u00B7 \u043A\u043E\u043C\u043F\u043E\u0437\u0438\u0446\u0438\u044F \u0434\u043E\u043F\u043E\u043B\u043D\u0435\u043D\u0430 \u043A \u044D\u0441\u043A\u0438\u0437\u0430\u043C"),
        React.createElement("div", { className: "mining-hero pearl-card" },
            React.createElement("div", { className: "mining-orb" }, icon('lightning', 100, true)),
            React.createElement("small", null, "\u0414\u043E\u0431\u044B\u0447\u0430 GM"),
            React.createElement("h1", null,
                nf(rate),
                " ",
                React.createElement("span", null, "GM / \u0441\u0443\u0442\u043A\u0438")),
            React.createElement("p", null,
                "Lv.",
                wallet.level,
                " \u00B7 Power +",
                powerBonus(wallet.level),
                "% \u00B7 Boost +",
                holdingBonus(wallet.vault),
                "%")),
        React.createElement("div", { className: "mining-store pearl-card" },
            React.createElement("div", { className: "flex-between" },
                React.createElement("b", null, "Storage"),
                React.createElement("span", null,
                    nf(wallet.storage),
                    " GM")),
            React.createElement("div", { className: "progress" },
                React.createElement("div", { style: { width: (Math.min(100, wallet.storage / (rate * storageHours(wallet.level) / 24) * 100)) + '%' } })),
            React.createElement("small", null,
                "\u0412\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C: ",
                storageHours(wallet.level),
                " \u0447\u0430\u0441\u043E\u0432 \u0434\u043E\u0431\u044B\u0447\u0438. \u0412 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u0440\u0435\u0436\u0438\u043C\u0435 \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u0440\u0435\u0437\u0435\u0440\u0432\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435.")),
        React.createElement(GButton, { theme: theme, onClick: miningClaim, icon: "lightning" }, "Claim GM"),
        React.createElement("div", { className: "feature-grid" }, [['lightning', 'Power', '+' + powerBonus(wallet.level) + '%'], ['clock', 'Storage', storageHours(wallet.level) + ' ч'], ['trending-up', 'Efficiency', wallet.level >= 9 ? '50%' : wallet.level >= 7 ? '40%' : wallet.level >= 5 ? '30%' : wallet.level >= 3 ? '20%' : '0%']].map(([i, t, v]) => React.createElement("div", { className: "feature-card pearl-card", key: t },
            icon(i, 28),
            React.createElement("small", null, t),
            React.createElement("b", null, v)))),
        React.createElement("p", { className: "disclaimer" }, "Mining Pool \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D 45 \u043C\u043B\u043D GM \u0438 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u043C \u0431\u044E\u0434\u0436\u0435\u0442\u043E\u043C. \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0435 \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C.")); }
    function Vault() { const amountN = Number(vaultAmount.replace(',', '.')); return React.createElement(React.Fragment, null,
        top('Holding (Vault)', true, 'info'),
        React.createElement("div", { className: "inferred-label" }, "\u0418\u0433\u0440\u043E\u0432\u043E\u0439 \u0440\u0430\u0437\u0434\u0435\u043B \u00B7 \u0430\u0434\u0430\u043F\u0442\u0430\u0446\u0438\u044F \u043E\u0431\u0449\u0435\u0433\u043E \u0441\u0442\u0438\u043B\u044F"),
        React.createElement("div", { className: "vault-hero pearl-card" },
            React.createElement("div", { className: "vault-orb" }, icon('database', 100, true)),
            React.createElement("small", null, "\u0412 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435"),
            React.createElement("h1", null,
                nf(wallet.vault),
                " GM"),
            React.createElement("p", null, "\u041C\u0430\u043A\u0441\u0438\u043C\u0443\u043C 0,5%/\u0441\u0443\u0442\u043A\u0438 \u00B7 \u043D\u0435 \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0440\u0443\u0435\u0442\u0441\u044F")),
        React.createElement("div", { className: "vault-stats" },
            React.createElement("div", { className: "pearl-card" },
                React.createElement("small", null, "Holding Boost"),
                React.createElement("b", null,
                    "+",
                    holdingBonus(wallet.vault),
                    "%")),
            React.createElement("div", { className: "pearl-card" },
                React.createElement("small", null, "\u0412\u044B\u0432\u043E\u0434"),
                React.createElement("b", null, "5% \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044F"))),
        React.createElement("div", { className: "form-surface pearl-card" },
            React.createElement("label", { htmlFor: "vault-amount" }, "\u0421\u0443\u043C\u043C\u0430 GM"),
            React.createElement("input", { id: "vault-amount", inputMode: "decimal", value: vaultAmount, onChange: (e) => setVaultAmount(e.target.value) }),
            React.createElement("div", { className: "twin-buttons" },
                React.createElement("button", { onClick: depositVault }, "\u041F\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u044C"),
                React.createElement("button", { onClick: withdrawVault }, "\u0412\u044B\u0432\u0435\u0441\u0442\u0438"))),
        React.createElement("p", { className: "disclaimer" }, "\u041E\u0434\u0438\u043D \u0432\u044B\u0432\u043E\u0434 \u0432 UTC-\u0441\u0443\u0442\u043A\u0438. \u0412\u043E\u0437\u043D\u0430\u0433\u0440\u0430\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0430\u0447\u0438\u0441\u043B\u044F\u044E\u0442\u0441\u044F \u043A\u0430\u0436\u0434\u044B\u0439 \u0447\u0430\u0441 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u0440\u0438 \u043D\u0430\u043B\u0438\u0447\u0438\u0438 \u0444\u043E\u043D\u0434\u0430. \u041D\u0438\u043A\u0430\u043A\u0438\u0445 \u0440\u0435\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0435\u043D\u0435\u0433."),
        !demo && React.createElement(React.Fragment, null,
            React.createElement("div", { className: "split-line" },
                React.createElement("span", null, "\u041D\u0430\u0433\u0440\u0430\u0434\u044B \u043A \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044E"),
                React.createElement("b", null,
                    nf((liveState?.holding?.pending_cents || 0) / 100),
                    " GM")),
            React.createElement(GButton, { theme: theme, disabled: !liveState?.holding?.pending_cents, onClick: () => gameAction('/api/vault/claim') }, "\u0417\u0430\u0431\u0440\u0430\u0442\u044C Holding Rewards"))); }
    function Shop() { return React.createElement(React.Fragment, null,
        top('GM Shop', true, 'swap'),
        React.createElement("div", { className: "shop-banner pearl-card" },
            icon('swap', 54, true),
            React.createElement("div", null,
                React.createElement("h2", null, "GM \u2192 CR"),
                React.createElement("p", null, "\u0412\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u043E\u0431\u043C\u0435\u043D, \u0431\u0435\u0437 \u0440\u0435\u0430\u043B\u044C\u043D\u044B\u0445 \u0434\u0435\u043D\u0435\u0433"))),
        React.createElement("div", { className: "form-surface pearl-card" },
            React.createElement("label", null, "\u041E\u0442\u0434\u0430\u0451\u0442\u0435 GM"),
            React.createElement("input", { inputMode: "decimal", value: shopAmount, onChange: (e) => { setShopAmount(e.target.value); setShopQuote(null); } }),
            React.createElement("div", { className: "split-line" },
                React.createElement("span", null, "\u041A\u043E\u043C\u0438\u0441\u0441\u0438\u044F GM Shop"),
                React.createElement("b", null, "1%")),
            React.createElement("div", { className: "split-line" },
                React.createElement("span", null, "\u041F\u043E\u0441\u043B\u0435 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438"),
                React.createElement("b", null,
                    nf(Math.max(0, Number(shopAmount.replace(',', '.') || 0) * .99)),
                    " GM")),
            React.createElement("div", { className: "split-line" },
                React.createElement("span", null, "\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u0435 CR"),
                React.createElement("b", null, shopQuote ? nf(shopQuote.cr_cents / 100) + ' CR' : 'Нужна котировка')),
            !demo && React.createElement(GButton, { theme: theme, disabled: !liveState?.config?.shop_enabled, onClick: async () => { const x = await api('/api/shop/quote?amount=' + encodeURIComponent(shopAmount.replace(',', '.'))); if (x)
                    setShopQuote(x); } }, "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0440\u044B\u043D\u043E\u0447\u043D\u044B\u0439 \u043A\u0443\u0440\u0441"),
            React.createElement(GButton, { theme: theme, disabled: demo || !shopQuote || !liveState?.config?.shop_enabled, onClick: async () => { const x = await gameAction('/api/shop/exchange', { amount: shopAmount.replace(',', '.'), minCrCents: shopQuote.cr_cents, quoteExpiresAt: shopQuote.quote_expires_at }); if (x)
                    setShopQuote(null); } }, "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043E\u0431\u043C\u0435\u043D GM \u2192 CR")),
        React.createElement("p", { className: "disclaimer" }, "\u041B\u0438\u043C\u0438\u0442: 50 000 CR \u0432 \u0441\u0443\u0442\u043A\u0438. \u0412\u0441\u0435 \u043F\u043E\u0442\u0440\u0430\u0447\u0435\u043D\u043D\u044B\u0435 GM \u043F\u043E\u0441\u0442\u0443\u043F\u0430\u044E\u0442 \u0432 Treasury, \u0432\u043A\u043B\u044E\u0447\u0430\u044F 1% \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438. \u0414\u043E \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0444\u043E\u0440\u043C\u0443\u043B\u044B \u043A\u0443\u0440\u0441\u0430 \u043E\u0431\u043C\u0435\u043D \u0437\u0430\u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u0430\u043D.")); }
    function Boxes() { return React.createElement(React.Fragment, null,
        top('GM Boxes', true, 'gift'),
        React.createElement("div", { className: "shop-banner pearl-card" },
            icon('gift', 65, true),
            React.createElement("div", null,
                React.createElement("h2", null, "\u041A\u043E\u0440\u043E\u0431\u043A\u0438 \u0437\u0430 POINTS"),
                React.createElement("p", null, "POINTS \u0432\u044B\u0434\u0430\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u044B\u0435 \u0441\u0434\u0435\u043B\u043A\u0438 GM/CR"))),
        React.createElement("div", { className: "vault-stats" },
            React.createElement("div", { className: "pearl-card" },
                React.createElement("small", null, "\u0414\u043E\u0441\u0442\u0443\u043F\u043D\u043E POINTS"),
                React.createElement("b", null, liveState?.points?.points || 0)),
            React.createElement("div", { className: "pearl-card" },
                React.createElement("small", null, "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E"),
                React.createElement("b", null,
                    liveState?.points?.daily_points || 0,
                    "/1000"))),
        [['bronze', 'Bronze', 300], ['silver', 'Silver', 750], ['gold', 'Gold', 1500]].map(([k, n, c]) => React.createElement("div", { className: "form-surface pearl-card", key: k },
            React.createElement("div", { className: "split-line" },
                React.createElement("b", null, n),
                React.createElement("span", null,
                    c,
                    " POINTS")),
            React.createElement(GButton, { theme: theme, disabled: demo || !liveState?.config?.boxes_enabled, onClick: () => gameAction('/api/boxes/open', { kind: k }) }, "\u041E\u0442\u043A\u0440\u044B\u0442\u044C"))),
        React.createElement("p", { className: "disclaimer" }, "\u0420\u0430\u0437\u043C\u0435\u0440 \u043D\u0430\u0433\u0440\u0430\u0434 \u043F\u043E\u043A\u0430 \u043D\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D \u0434\u0432\u0443\u043C\u044F \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430\u043C\u0438. \u0421\u0435\u0440\u0432\u0435\u0440 \u043D\u0435 \u0432\u044B\u0434\u0430\u0451\u0442 \u043D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0435 GM.")); }
    function Referrals() { return React.createElement(React.Fragment, null,
        top('Referral Program', true, 'friends'),
        React.createElement("div", { className: "referral-hero pearl-card" },
            icon('friends', 80, true),
            React.createElement("h2", null, "\u041F\u0440\u0438\u0433\u043B\u0430\u0448\u0430\u0439 \u0434\u0440\u0443\u0437\u0435\u0439"),
            React.createElement("p", null, "25% \u043E\u0442 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0445 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0451\u043D\u043D\u044B\u043C\u0438 Holding Rewards")),
        React.createElement("div", { className: "invite-link pearl-card" },
            React.createElement("small", null, "\u041F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0441\u044B\u043B\u043A\u0430"),
            React.createElement("div", null,
                React.createElement("code", null, demo ? 'Демо · ссылка появится в Telegram' : 't.me/gm_token_test_bot?startapp=ref_' + String(webapp?.initDataUnsafe?.user?.id || '')),
                React.createElement("button", { onClick: () => { navigator.clipboard?.writeText('https://t.me/gm_token_test_bot?startapp=ref_' + String(webapp?.initDataUnsafe?.user?.id || 'demo')); flash(demo ? 'Демонстрационная ссылка' : 'Реферальная ссылка скопирована'); } }, icon('copy', 21)))),
        React.createElement("div", { className: "stats-grid" },
            React.createElement("div", { className: "stat-card" },
                React.createElement("b", null, demo ? 128 : (liveReferrals?.referred?.length || 0)),
                React.createElement("small", null,
                    "\u0414\u0440\u0443\u0437\u0435\u0439 ",
                    demo ? "(демо)" : "")),
            React.createElement("div", { className: "stat-card" },
                React.createElement("b", null, demo ? '0.00' : nf((liveReferrals?.received_gm_cents || 0) / 100)),
                React.createElement("small", null,
                    "\u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E GM ",
                    demo ? '(демо)' : ''))),
        React.createElement("p", { className: "disclaimer" }, "\u0412 \u0440\u0430\u0431\u043E\u0447\u0435\u043C \u0440\u0435\u0436\u0438\u043C\u0435 \u0441\u0441\u044B\u043B\u043A\u0430 \u0432\u043A\u043B\u044E\u0447\u0430\u0435\u0442 \u0432\u0430\u0448 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0439 Telegram ID. \u0412\u043E\u0437\u043D\u0430\u0433\u0440\u0430\u0436\u0434\u0435\u043D\u0438\u0435 \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430 \u0444\u0430\u043A\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0439 Holding Claim \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0451\u043D\u043D\u043E\u0433\u043E.")); }
    function History() { return React.createElement(React.Fragment, null,
        top('Transaction History', true, 'clock'),
        React.createElement("div", { className: "empty-state" },
            icon('clock', 62, true),
            React.createElement("h3", null, "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439"),
            demo ? React.createElement("p", null, "\u0414\u0435\u043C\u043E-\u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u0440\u0435\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u044F\u043C\u0438.") : React.createElement("button", { onClick: loadHistory }, "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430")),
        serverHistory.map((x) => React.createElement("div", { key: x.id, className: "pearl-card form-surface" },
            React.createElement("b", null, x.kind),
            React.createElement("small", null, new Date(x.at * 1000).toLocaleString('ru-RU')),
            React.createElement("p", null, x.info)))); }
    function Achievements() { const items = demo ? [{ id: 'a', icon: 'lightning', title: 'Первый Claim', description: 'Получить GM с Mining' }, { id: 'b', icon: 'friends', title: 'Первый друг', description: 'Пригласить пользователя' }, { id: 'c', icon: 'coins', title: 'Holding', description: 'Поместить GM в Vault' }, { id: 'd', icon: 'trophy', title: 'LVL 10', description: 'Достичь максимального уровня' }] : liveAchievements; return React.createElement(React.Fragment, null,
        top('Achievements', true, 'trophy'),
        React.createElement("div", { className: "achievement-list" }, items.map((t) => React.createElement("div", { className: "earn-item pearl-card", key: t.id },
            icon(t.icon || 'trophy', 45, true),
            React.createElement("span", null,
                React.createElement("b", null, t.title || t.id),
                React.createElement("small", null,
                    t.description || '',
                    !demo ? ` · ${t.xp || 0} XP` : '')),
            !demo && React.createElement("button", { disabled: t.claimed || !t.available, onClick: async () => { const x = await gameAction('/api/achievements/claim', { id: t.id }); if (x)
                    await refreshLive(); } }, t.claimed ? 'Получено' : t.available ? 'Получить' : 'Не выполнено')))),
        !items.length && React.createElement("p", { className: "disclaimer" }, "\u0414\u043E\u0441\u0442\u0438\u0436\u0435\u043D\u0438\u044F \u0435\u0449\u0451 \u043D\u0435 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u044B \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430\u043C\u0438. \u0421\u043A\u0440\u044B\u0442\u044B\u0435 \u043D\u0430\u0433\u0440\u0430\u0434\u044B \u043D\u0435 \u043D\u0430\u0447\u0438\u0441\u043B\u044F\u044E\u0442\u0441\u044F.")); }
    function Settings() { return React.createElement(React.Fragment, null,
        top('Settings', true, 'settings'),
        React.createElement("div", { className: "settings-card pearl-card" },
            React.createElement("b", null, "\u0422\u0435\u043C\u0430 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u044F"),
            React.createElement("p", null, "\u041A\u0430\u0436\u0434\u0430\u044F \u0442\u0435\u043C\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0435 PNG-\u0438\u043A\u043E\u043D\u043A\u0438 \u0438 \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0435 \u0444\u0430\u043A\u0442\u0443\u0440\u044B."),
            React.createElement("div", { className: "setting-theme" },
                React.createElement("button", { className: theme === 'light' ? 'on' : '', onClick: () => setTheme('light') }, "Light \u00B7 \u0441\u0432\u0435\u0442\u043B\u0430\u044F"),
                React.createElement("button", { className: theme === 'dark' ? 'on' : '', onClick: () => setTheme('dark') }, "Dark \u00B7 \u0442\u0451\u043C\u043D\u0430\u044F"))),
        React.createElement("button", { className: "earn-item pearl-card", onClick: () => flash('Уведомления управляются настройками Telegram') },
            icon('notifications', 33),
            React.createElement("span", null,
                React.createElement("b", null, "\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F"),
                React.createElement("small", null, "Telegram \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u044F\u0435\u0442 \u043E \u0432\u0430\u0436\u043D\u044B\u0445 \u0441\u043E\u0431\u044B\u0442\u0438\u044F\u0445")),
            icon('chevron-right', 18)),
        React.createElement("p", { className: "disclaimer" }, "Telegram Mini App: \u0431\u0435\u0437 \u0434\u0443\u0431\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0441\u0442\u0430\u0442\u0443\u0441-\u0431\u0430\u0440\u0430, \u0441 \u0443\u0447\u0451\u0442\u043E\u043C safe-area.")); }
    function Support() {
        const arr = demo ? wallet.tickets : supportTickets;
        return React.createElement(React.Fragment, null,
            top('Support Center', true, 'info'),
            React.createElement("div", { className: "support-heading pearl-card" },
                icon('shield-check', 40, true),
                React.createElement("div", null,
                    React.createElement("b", null, "GM Auto Support"),
                    React.createElement("small", null, "\u041F\u0440\u0438\u0451\u043C \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u0439 24/7; \u0434\u0432\u0435 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u043E\u043F\u044B\u0442\u043A\u0438 \u0434\u043E \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u043C\u043E\u0434\u0435\u0440\u0430\u0442\u043E\u0440\u0443. \u0410\u043F\u0435\u043B\u043B\u044F\u0446\u0438\u0438 \u2014 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0443 \u0441\u0440\u0430\u0437\u0443."))),
            React.createElement("div", { className: "form-surface pearl-card" },
                React.createElement("label", null, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F"),
                React.createElement("select", { value: supportCategory, onChange: (e) => setSupportCategory(e.target.value) }, ['Общий вопрос', 'Mining', 'Holding', 'Биржа GM/CR', 'Баланс GM/CR', 'Апелляция', 'Рефералы'].map(x => React.createElement("option", { key: x }, x))),
                React.createElement("label", null, "\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B"),
                React.createElement("textarea", { rows: 5, value: supportText, onChange: (e) => setSupportText(e.target.value), placeholder: "\u041E\u043F\u0438\u0448\u0438 \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u044E \u043C\u0438\u043D\u0438\u043C\u0443\u043C \u0432 10 \u0441\u0438\u043C\u0432\u043E\u043B\u0430\u0445" }),
                React.createElement(GButton, { theme: theme, onClick: createTicket },
                    "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0442\u0438\u043A\u0435\u0442 ",
                    demo ? '(демо)' : '')),
            React.createElement("div", { className: "flex-between" },
                React.createElement("h3", { className: "section-title" }, "\u041E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F"),
                React.createElement("button", { className: "small-button", onClick: loadTickets }, "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C")),
            arr.length ? arr.map((t) => React.createElement("div", { className: "support-ticket pearl-card", key: t.id },
                React.createElement("b", null,
                    "#",
                    String(t.id).slice(0, 8),
                    " \u00B7 ",
                    t.category),
                React.createElement("span", null, clean(t.body || t.text)),
                React.createElement("small", null,
                    t.status,
                    " \u00B7 ",
                    demo ? 'локальное демо' : 'серверный тикет',
                    " \u00B7 ",
                    t.priority || 'P3'),
                !demo && t.user_id === String(webapp?.initDataUnsafe?.user?.id || '') && t.status !== 'closed' && React.createElement("button", { className: "small-button", onClick: () => ticketAction(t.id, 'auto') },
                    "\u0410\u0432\u0442\u043E\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 (",
                    t.auto_attempts || 0,
                    "/2)"),
                !demo && ['owner', 'coowner', 'moderator'].includes(liveRole) && t.status === 'open' && React.createElement("button", { className: "small-button", onClick: () => ticketAction(t.id, 'claim') }, "\u0412\u0437\u044F\u0442\u044C \u0432 \u0440\u0430\u0431\u043E\u0442\u0443"),
                !demo && ['owner', 'coowner', 'moderator'].includes(liveRole) && t.status === 'in_review' && React.createElement(React.Fragment, null,
                    React.createElement("input", { placeholder: "\u041E\u0442\u0432\u0435\u0442 \u0438\u0433\u0440\u043E\u043A\u0443", value: staffReply, onChange: (e) => setStaffReply(e.target.value) }),
                    React.createElement("button", { className: "small-button", onClick: () => ticketAction(t.id, 'reply', { body: staffReply }) }, "\u041E\u0442\u0432\u0435\u0442\u0438\u0442\u044C"),
                    React.createElement("button", { className: "small-button", onClick: () => ticketAction(t.id, 'resolve') }, "\u0420\u0435\u0448\u0435\u043D\u043E")),
                !demo && t.user_id === String(webapp?.initDataUnsafe?.user?.id || '') && ['resolved', 'closed'].includes(t.status) && React.createElement("button", { className: "small-button", onClick: () => ticketAction(t.id, 'reopen') }, "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E"))) : React.createElement("p", { className: "disclaimer" }, "\u041F\u043E\u043A\u0430 \u043D\u0435\u0442 \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u0439. \u0412 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u0432\u0435\u0440\u0441\u0438\u0438 \u043C\u043E\u0436\u043D\u043E \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043E\u0447\u0435\u0440\u0435\u0434\u044C \u043A\u043D\u043E\u043F\u043A\u043E\u0439 \u0432\u044B\u0448\u0435."));
    }
    function Admin() {
        const isOwner = ['owner', 'coowner'].includes(liveRole);
        if (!demo && !isOwner)
            return React.createElement(React.Fragment, null,
                top('Admin Panel', true, 'shield-check'),
                React.createElement("div", { className: "empty-state" },
                    icon('shield-check', 70, true),
                    React.createElement("h2", null, "\u0414\u043E\u0441\u0442\u0443\u043F \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D"),
                    React.createElement("p", null, "\u0422\u043E\u043B\u044C\u043A\u043E Owner \u0438 Co-Owner \u043C\u043E\u0433\u0443\u0442 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u0443\u044E \u043F\u0430\u043D\u0435\u043B\u044C. \u0420\u043E\u043B\u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u0441\u0435\u0440\u0432\u0435\u0440\u043E\u043C.")));
        return React.createElement(React.Fragment, null,
            top('Admin Panel', true, 'settings'),
            React.createElement("div", { className: "admin-banner pearl-card" },
                icon('crown', 49, true),
                React.createElement("div", null,
                    React.createElement("b", null, demo ? 'Owner / Co-Owner · DEMO' : liveRole.toUpperCase()),
                    React.createElement("small", null, demo ? 'Это визуальный макет без прав на изменение балансов' : 'Вход подтверждён Telegram; критические операции требуют TOTP'))),
            React.createElement("div", { className: "admin-numbers" }, [['Users', '48 256'], ['Mining Pool', '45M GM'], ['Holding Rewards', '23M GM'], ['Open Tickets', '—']].map(([a, b]) => React.createElement("div", { className: "pearl-card", key: a },
                React.createElement("small", null, a),
                React.createElement("b", null, b),
                React.createElement("small", null, "\u041F\u0440\u0438\u043C\u0435\u0440")))),
            React.createElement("h3", { className: "section-title" }, "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0435"),
            React.createElement("div", { className: "admin-actions pearl-card" },
                React.createElement("button", { onClick: async () => { const x = await adminRequest('/api/admin/team'); if (x)
                        setAdminTeam(x.team || []); } },
                    icon('friends', 21),
                    " \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0440\u043E\u043B\u0435\u0439"),
                React.createElement("button", { onClick: async () => { const x = await adminRequest('/api/admin/pools'); if (x)
                        setAdminFunds(x.pools || []); } },
                    icon('database', 21),
                    " \u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u0444\u043E\u043D\u0434\u043E\u0432")),
            adminTeam.length > 0 && React.createElement("div", { className: "admin-records pearl-card" }, adminTeam.map((x) => React.createElement("div", { key: x.id },
                React.createElement("span", null, x.username || x.id),
                React.createElement("b", null, x.role)))),
            adminFunds.length > 0 && React.createElement("div", { className: "admin-records pearl-card" }, adminFunds.map((x) => React.createElement("div", { key: x.name },
                React.createElement("span", null, x.name),
                React.createElement("b", null,
                    nf((x.gm || x.cr) / 100),
                    " ",
                    x.gm ? 'GM' : 'CR')))),
            React.createElement("div", { className: "form-surface pearl-card" },
                React.createElement("b", null, "\u041C\u043E\u0434\u0435\u0440\u0430\u0442\u043E\u0440\u044B"),
                React.createElement("label", null, "Telegram ID \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0430"),
                React.createElement("input", { value: adminId, onChange: (e) => setAdminId(e.target.value), placeholder: "\u0422\u043E\u043B\u044C\u043A\u043E \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 ID" }),
                React.createElement("label", null, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435"),
                React.createElement("select", { value: adminAction, onChange: (e) => setAdminAction(e.target.value) },
                    React.createElement("option", { value: "grant" }, "\u0412\u044B\u0434\u0430\u0442\u044C Moderator"),
                    React.createElement("option", { value: "revoke" }, "\u041E\u0442\u043E\u0437\u0432\u0430\u0442\u044C Moderator")),
                React.createElement("label", null, "\u041A\u043E\u0434 2FA \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430"),
                React.createElement("input", { value: adminCode, onChange: (e) => setAdminCode(e.target.value), inputMode: "numeric", placeholder: "6-\u0437\u043D\u0430\u0447\u043D\u044B\u0439 TOTP" }),
                React.createElement(GButton, { theme: theme, onClick: adminChangeRole, disabled: demo }, "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0440\u043E\u043B\u044C")),
            React.createElement("div", { className: "form-surface pearl-card" },
                React.createElement("b", null, "\u041F\u0435\u0440\u0435\u0432\u043E\u0434 \u043C\u0435\u0436\u0434\u0443 \u0438\u0433\u0440\u043E\u0432\u044B\u043C\u0438 \u0444\u043E\u043D\u0434\u0430\u043C\u0438"),
                React.createElement("label", null, "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A"),
                React.createElement("select", { value: adminFrom, onChange: (e) => setAdminFrom(e.target.value) },
                    React.createElement("option", { value: "TREASURY" }, "Treasury"),
                    React.createElement("option", { value: "FUTURE" }, "Future Ecosystem")),
                React.createElement("label", null, "\u041F\u043E\u043B\u0443\u0447\u0430\u0442\u0435\u043B\u044C"),
                React.createElement("select", { value: adminTo, onChange: (e) => setAdminTo(e.target.value) }, ['MINING', 'HOLDING', 'BOXES', 'DAILY', 'COMMUNITY', 'DEVELOPMENT'].map(x => React.createElement("option", { key: x }, x))),
                React.createElement("label", null, "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E GM"),
                React.createElement("input", { value: adminAmount, onChange: (e) => setAdminAmount(e.target.value), inputMode: "decimal" }),
                React.createElement("label", null, "\u041F\u0440\u0438\u0447\u0438\u043D\u0430 (15+ \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432)"),
                React.createElement("textarea", { rows: 3, value: adminReason, onChange: (e) => setAdminReason(e.target.value) }),
                React.createElement(GButton, { theme: theme, onClick: adminTransfer, disabled: demo }, "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u0435\u0440\u0435\u0432\u043E\u0434 + 2FA")),
            React.createElement("div", { className: "form-surface pearl-card" },
                React.createElement("b", null, "\u041A\u043E\u0440\u0440\u0435\u043A\u0446\u0438\u044F \u043E\u0448\u0438\u0431\u043E\u0447\u043D\u043E\u0433\u043E \u0431\u0430\u043B\u0430\u043D\u0441\u0430"),
                React.createElement("small", null, "\u0422\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0442\u0438\u043A\u0435\u0442\u0443 \u0438 \u0441 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u043E\u0439 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E\u0433\u043E \u0440\u0435\u0437\u0435\u0440\u0432\u0430."),
                React.createElement("label", null, "ID \u0438\u0433\u0440\u043E\u043A\u0430 (\u0432\u044B\u0448\u0435)"),
                React.createElement("input", { value: adminId, onChange: (e) => setAdminId(e.target.value) }),
                React.createElement("label", null, "\u0412\u0430\u043B\u044E\u0442\u0430"),
                React.createElement("select", { value: adminCorrectionCurrency, onChange: (e) => { setAdminCorrectionCurrency(e.target.value); setAdminCorrectionPool(e.target.value === 'GM' ? 'MINING' : 'WELCOME'); } },
                    React.createElement("option", null, "GM"),
                    React.createElement("option", null, "CR")),
                React.createElement("label", null, "\u0424\u043E\u043D\u0434-\u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0438"),
                React.createElement("select", { value: adminCorrectionPool, onChange: (e) => setAdminCorrectionPool(e.target.value) }, (adminCorrectionCurrency === 'GM' ? ['MINING', 'BOXES', 'DAILY', 'COMMUNITY', 'DEVELOPMENT', 'FUTURE', 'TREASURY'] : ['WELCOME', 'SHOP']).map(x => React.createElement("option", { key: x }, x))),
                React.createElement("label", null, "\u041D\u043E\u043C\u0435\u0440 \u0442\u0438\u043A\u0435\u0442\u0430"),
                React.createElement("input", { value: adminTicket, onChange: (e) => setAdminTicket(e.target.value), placeholder: "GM-..." }),
                React.createElement("label", null, "\u0421\u0443\u043C\u043C\u0430 (\u0432\u044B\u0448\u0435)"),
                React.createElement("input", { value: adminAmount, onChange: (e) => setAdminAmount(e.target.value) }),
                React.createElement(GButton, { theme: theme, onClick: adminCorrection, disabled: demo }, "\u0418\u0441\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0447\u0435\u0440\u0435\u0437 \u0440\u0435\u0437\u0435\u0440\u0432 + 2FA")),
            React.createElement("p", { className: "disclaimer" }, "\u0412 \u0434\u0435\u043C\u043E \u0432\u0441\u0435 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u044B. \u0423 \u0434\u0432\u0443\u0445 \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0435\u0432 \u043E\u0434\u0438\u043D\u0430\u043A\u043E\u0432\u044B\u0435 \u0437\u0430\u0449\u0438\u0449\u0451\u043D\u043D\u044B\u0435 \u043F\u0440\u0430\u0432\u0430; \u0432\u043B\u0430\u0434\u0435\u043B\u0435\u0446 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0430 \u0447\u0435\u0440\u0435\u0437 UI."));
    }
    function More() { return React.createElement(React.Fragment, null,
        top('Все разделы', true, 'more'),
        React.createElement("div", { className: "more-grid" }, [['lightning', 'Mining', 'mining'], ['coins', 'Holding Vault', 'vault'], ['swap', 'GM Shop', 'shop'], ['gift', 'GM Boxes', 'boxes'], ['candlesticks', 'Биржа GM/CR', 'trade'], ['gift', 'Daily Reward', 'reward'], ['tasks', 'Задания', 'tasks'], ['trophy', 'Рейтинг', 'leaderboard'], ['friends', 'Рефералы', 'referrals'], ['clock', 'История', 'history'], ['shield-check', 'Support', 'support'], ['settings', 'Settings', 'settings'], ['crown', 'Admin · demo', 'admin']].map(([i, t, s]) => React.createElement("button", { className: "earn-item pearl-card", key: t, onClick: () => goto(s) },
            icon(i, 37, true),
            React.createElement("span", null,
                React.createElement("b", null, t)),
            icon('chevron-right', 18))))); }
    function Streak() { return React.createElement(React.Fragment, null,
        top('7 Day Streak', true, 'flame'),
        React.createElement("div", { className: "referral-hero pearl-card" },
            icon('flame', 90, true),
            React.createElement("h1", null,
                wallet.streak,
                " \u0434\u043D\u0435\u0439"),
            React.createElement("p", null, "\u0421\u0435\u0440\u0438\u044F \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u044B\u0445 \u043F\u043E\u0441\u0435\u0449\u0435\u043D\u0438\u0439. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u043E\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0435 \u043D\u0430\u0433\u0440\u0430\u0434\u044B \u0432 \u043E\u0434\u0438\u043D \u0434\u0435\u043D\u044C \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043E.")),
        React.createElement(GButton, { theme: theme, onClick: () => goto('reward') }, "\u0415\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u0430\u044F \u043D\u0430\u0433\u0440\u0430\u0434\u0430")); }
    let view;
    switch (screen) {
        case 'home':
            view = Home();
            break;
        case 'trade':
            view = Trading();
            break;
        case 'earn':
            view = Earn();
            break;
        case 'tasks':
            view = Tasks();
            break;
        case 'leaderboard':
            view = Leaderboard();
            break;
        case 'profile':
            view = Profile();
            break;
        case 'reward':
            view = Reward();
            break;
        case 'splash':
            view = Splash();
            break;
        case 'mining':
            view = Mining();
            break;
        case 'vault':
            view = Vault();
            break;
        case 'shop':
            view = Shop();
            break;
        case 'boxes':
            view = Boxes();
            break;
        case 'referrals':
            view = Referrals();
            break;
        case 'history':
            view = History();
            break;
        case 'settings':
            view = Settings();
            break;
        case 'support':
            view = Support();
            break;
        case 'admin':
            view = Admin();
            break;
        case 'achievements':
            view = Achievements();
            break;
        case 'more':
            view = More();
            break;
        case 'streak':
            view = Streak();
            break;
        default: view = Home();
    }
    return React.createElement("div", { className: 'application theme-' + theme + (webapp?.initData ? ' is-telegram' : '') },
        React.createElement("aside", { className: "desktop-toolbar" },
            React.createElement("div", { className: "toolbar-logo" },
                React.createElement(Brand, { theme: theme, size: 42 }),
                React.createElement("span", null,
                    React.createElement("b", null, "GM TOKEN"),
                    React.createElement("small", null, "\u041E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u044D\u0441\u043A\u0438\u0437\u044B \u00B7 \u0438\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u0430\u044F \u0441\u0431\u043E\u0440\u043A\u0430"))),
            React.createElement("div", { className: "toolbar-tabs" },
                React.createElement("button", { onClick: () => setTheme('light'), className: isLight ? 'chosen' : '' }, "Light"),
                React.createElement("button", { onClick: () => setTheme('dark'), className: !isLight ? 'chosen' : '' }, "Dark")),
            React.createElement("div", { className: "toolbar-links" }, ['home', 'trade', 'earn', 'tasks', 'leaderboard', 'profile', 'mining', 'vault', 'shop', 'support', 'admin'].map(s => React.createElement("button", { key: s, className: screen === s ? 'chosen' : '', onClick: () => goto(s) }, s))),
            React.createElement("p", null, "\u041E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0435 PNG \u00B7 54 \u0438\u043A\u043E\u043D\u043A\u0438 \u00D7 4 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u0430 \u00B7 \u0431\u0435\u0437 \u043F\u043E\u0434\u043C\u0435\u043D\u044B \u0441\u0442\u043E\u0440\u043E\u043D\u043D\u0438\u043C\u0438 \u043F\u0438\u043A\u0442\u043E\u0433\u0440\u0430\u043C\u043C\u0430\u043C\u0438")),
        React.createElement("div", { className: "device-stage" },
            React.createElement("div", { className: "phone-frame" },
                React.createElement("div", { className: 'phone-scroll ' + ((screen === 'reward' || screen === 'splash') ? 'no-scroll' : '') }, view),
                !['reward', 'splash'].includes(screen) && bottom(),
                React.createElement("div", { className: "home-indicator" })),
            React.createElement("div", { className: "underphone" },
                React.createElement("span", { className: "demo-pill" }, demo ? 'ДЕМО · изменения только локальные' : 'Серверная авторизация'),
                React.createElement("button", { onClick: () => goto('splash') }, "\u0417\u0430\u0441\u0442\u0430\u0432\u043A\u0430"),
                React.createElement("button", { onClick: () => goto('home') }, "Home"),
                React.createElement("button", { onClick: () => setTheme(isLight ? 'dark' : 'light') }, "\u0421\u043C\u0435\u043D\u0438\u0442\u044C \u0442\u0435\u043C\u0443")),
            React.createElement("small", { className: "status-note" }, backendStatus)),
        toast && React.createElement("div", { className: "toast-message", role: "status", onClick: () => setToast('') },
            toast,
            React.createElement("button", { onClick: () => setToast('') }, "\u00D7")),
        modal && React.createElement("div", { className: "overlay", onClick: () => setModal('') },
            React.createElement("div", { className: "modal-box", onClick: (e) => e.stopPropagation() },
                React.createElement("b", null, modal === 'tradeForm' ? (side === 'buy' ? 'Buy GM' : 'Sell GM') : 'Подтверждение ордера'),
                modal === 'tradeForm' ? React.createElement(React.Fragment, null,
                    React.createElement("p", null,
                        "\u041F\u0430\u0440\u0430 GM/CR \u00B7 ",
                        demo ? 'ДЕМО' : 'виртуальные GM/CR'),
                    React.createElement("label", null, "\u0422\u0438\u043F \u043E\u0440\u0434\u0435\u0440\u0430"),
                    React.createElement("select", { value: orderType, onChange: (e) => setOrderType(e.target.value) },
                        React.createElement("option", { value: "limit" }, "Limit"),
                        React.createElement("option", { value: "market" }, "Market (3% \u0437\u0430\u0449\u0438\u0442\u0430)")),
                    React.createElement("label", null, "\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E GM"),
                    React.createElement("input", { inputMode: "decimal", value: amount, onChange: (e) => setAmount(e.target.value) }),
                    orderType === 'limit' && React.createElement(React.Fragment, null,
                        React.createElement("label", null, "\u0426\u0435\u043D\u0430 CR \u0437\u0430 1 GM"),
                        React.createElement("input", { inputMode: "decimal", value: orderPrice, onChange: (e) => setOrderPrice(e.target.value) }),
                        React.createElement("label", null, "\u0421\u0440\u043E\u043A \u043E\u0440\u0434\u0435\u0440\u0430"),
                        React.createElement("select", { value: orderDuration, onChange: (e) => setOrderDuration(e.target.value) }, ['1h', '6h', '12h', '24h', '3d', '7d', 'GTC'].map(x => React.createElement("option", { key: x }, x)))),
                    React.createElement("div", { className: "amount-presets" }, ['25', '50', '75', '100'].map(x => React.createElement("button", { key: x, onClick: () => setAmount(x) }, x))),
                    React.createElement("button", { className: "modal-action", onClick: tradePreview }, "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0440\u0430\u0441\u0447\u0451\u0442")) : React.createElement(React.Fragment, null,
                    React.createElement("p", null, modalText),
                    React.createElement("button", { className: "modal-action", onClick: submitOrder }, demo ? 'Закрыть демонстрацию' : 'Подтвердить и отправить заявку')),
                React.createElement("button", { className: "modal-close", onClick: () => setModal('') }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044C"))));
}
// Offline renderer uses the bundled React 16.0 UMD (no built-in Hooks). A tiny
// isolated adapter keeps the same React/TSX source working in preview.html.
// When loaded with modern React (Vite production), native hooks are used.
if (typeof React.Fragment === 'undefined') {
    React.Fragment = function OfflineFragment(props) { return React.createElement('div', { style: { display: 'contents' } }, props.children); };
}
if (typeof React.useState !== 'function') {
    let active = null;
    React.useState = (initial) => {
        const owner = active, idx = owner.cursor++;
        if (!(idx in owner.slot))
            owner.slot[idx] = typeof initial === 'function' ? initial() : initial;
        return [owner.slot[idx], (next) => {
                owner.slot[idx] = typeof next === 'function' ? next(owner.slot[idx]) : next;
                owner.setState((old) => ({ tick: old.tick + 1 }));
            }];
    };
    React.useRef = (initial) => { const owner = active, idx = owner.cursor++; if (!(idx in owner.slot))
        owner.slot[idx] = { current: initial }; return owner.slot[idx]; };
    React.useEffect = (fn, deps) => {
        const owner = active, idx = owner.cursor++;
        let prev = owner.dependencies[idx];
        if (!prev || !deps || deps.some((x, i) => x !== prev[i])) {
            owner.dependencies[idx] = deps ? deps.slice() : undefined;
            owner.pending.push(fn);
        }
    };
    class OfflineHooks extends React.Component {
        slot = [];
        dependencies = [];
        pending = [];
        cursor = 0;
        constructor(props) { super(props); this.state = { tick: 0 }; }
        render() { active = this; this.cursor = 0; const el = App(); active = null; return el; }
        componentDidMount() { this.run(); }
        componentDidUpdate() { this.run(); }
        run() { const a = this.pending.splice(0); for (const f of a)
            f(); }
    }
    ReactDOM.render(React.createElement(OfflineHooks, null), document.getElementById('root'));
}
else {
    ReactDOM.render(React.createElement(App, null), document.getElementById('root'));
}
